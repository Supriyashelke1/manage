using manage.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace manage.AddControllers
{

    public class AppointmentController: Controller
    {
        /*private readonly IAppointmentRepository _appointmentRepository;

        public AppointmentController(IAppointmentRepository appointmentRepository)
        {
            _appointmentRepository = appointmentRepository;
        }

        public IActionResult List()
        {
            var appointments= _appointmentRepository.GetAllAppointments();
            return View(appointments);
        }*/
        public IActionResult List()
        {
            List<Appointment> appointments = GetSampleAppointments();
            return View(appointments);

        }
        private List<Appointment> GetSampleAppointments()
        {
            return new List<Appointment>
            {
                new Appointment {Id=1, Date= DateTime.Now.AddDays(7), Purpose="Interview", Location="TCS Office"},
                new Appointment {Id=2, Date= DateTime.Now.AddDays(14), Purpose="Interview", Location="Accenture Office"},
                new Appointment {Id=3, Date= DateTime.Now.AddDays(21), Purpose="Examination", Location="Powai"}

            };
        }
    }
}