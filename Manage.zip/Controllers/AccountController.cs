using Microsoft.AspNetCore.Mvc;

namespace manage.AddControllers
{

public class AccountController:Controller
{
    [HttpGet]
    public IActionResult Login()
    {
        //var model = new LoginViewModel();
        return View ();
    }

    [HttpPost]
    public IActionResult Login(string username, string password)
    /*{
        var user= _dbContext.ApplicationUser.FirstOrDefault(u=> u.Username ==username && u.Password ==password);

        if (user!=null)*/
        {

        if (username =="user" && password =="password")
    
    {
        return RedirectToAction("List","Appointment");
    }
    else
    {
        ViewBag.ErrorMessage="Invalid username or password.";
        return View();

    }
}
}
}

