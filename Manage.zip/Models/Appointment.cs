using System;

namespace manage.Models
{
    public class Appointment
    {
        public int Id {get; set;}
        public DateTime Date {get; set;}
        public string Purpose {get; set;}
        public string Location {get; set;}
    }
}