using System;
using System.Collections.Generic;
using System.Linq;

namespace manage.Models{

    public class AppointmentRepository
    {
        private List<Appointment> _appointments;

        public AppointmentRepository()
        {
            _appointments= new List<Appointment>
            {
                new Appointment {Id=1, Date= DateTime.Now.AddDays(7), Purpose="Interview", Location="TCS Office"},
                new Appointment {Id=2, Date= DateTime.Now.AddDays(14), Purpose="Interview", Location="Accenture Office"},
                new Appointment {Id=3, Date= DateTime.Now.AddDays(21), Purpose="Examination", Location="Powai"}
            };
        }
        public IEnumerable<Appointment>GetAllAppointments()
        {
            return _appointments;
        }

        /*public Appointment GetAppointmentById(int Id)
        {
            return _appointments.FirstOrDefault(a => a.Id == id);
        }*/
    }
}